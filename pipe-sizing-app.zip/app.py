import streamlit as st
import pandas as pd
import altair as alt
from openpyxl import load_workbook
from io import BytesIO
from pathlib import Path
from PIL import Image
import io
import base64
import traceback

from st_aggrid import AgGrid, GridOptionsBuilder, JsCode


def main():
    st.set_page_config(page_title='Pipe Sizing Explorer', layout='wide')

    # Styling: lighter water-blue background and darker text
    st.markdown(
        """
        <style>
        /* lighter water-blue background and darker text */
        .stApp { background-color: #e8f7ff; color: #03263a; }
        .css-18e3th9 {background-color: #e8f7ff;} /* main area fallback */
        .stButton>button {background-color:#0b82bf; color: #ffffff}
        .stDownloadButton>button {background-color:#0b82bf; color: #ffffff}
        .stSidebar {background-color:#cfeefc}
        .stMarkdown div{color: #03263a}
        img.logo-right {max-height:100px}
        
        /* Center all AgGrid headers - NUCLEAR OPTION */
        .ag-header-cell-label {
            text-align: center !important;
            justify-content: center !important;
            display: flex !important;
            align-items: center !important;
        }
        .ag-header-cell {
            text-align: center !important;
            justify-content: center !important;
        }
        .ag-header-cell-text {
            text-align: center !important;
        }
        
        /* Make table bigger and fill more space */
        .ag-theme-streamlit {
            height: 600px !important;
            width: 100% !important;
            font-size: 16px !important;
        }
        .ag-center-cols-container {
            width: 100% !important;
        }
        
        /* FORCE larger text in ALL table cells and headers */
        .ag-cell, .ag-header-cell-label, .ag-header-cell-text {
            font-size: 18px !important;
            font-weight: bold !important;
            font-family: 'FrankTheArchitect', monospace !important;
        }
        
        /* FORCE center ALL table headers */
        .ag-header {
            text-align: center !important;
        }
        .ag-header-viewport {
            text-align: center !important;
        }
        .ag-header-container {
            text-align: center !important;
        }
        
        /* ULTIMATE NUCLEAR HEADER CENTERING - TARGET EVERY POSSIBLE SELECTOR */
        .ag-header-cell-comp-wrapper {
            justify-content: center !important;
            display: flex !important;
        }
        .ag-header-cell-label .ag-header-cell-text {
            text-align: center !important;
            width: 100% !important;
        }
        .ag-header-group-cell-label {
            justify-content: center !important;
            display: flex !important;
        }
        
        /* ELIMINATE WHITE SPACE - USE FULL HEIGHT */
        .ag-root-wrapper {
            height: 100% !important;
        }
        .ag-body-viewport {
            height: 100% !important;
        }
        div[data-testid="stAgGrid"] {
            height: 80vh !important;
        }
        
        /* ULTIMATE NUCLEAR HEADER CENTERING - TARGET EVERY POSSIBLE SELECTOR */
        .ag-header-cell-comp-wrapper {
            justify-content: center !important;
            display: flex !important;
        }
        .ag-header-cell-label .ag-header-cell-text {
            text-align: center !important;
            width: 100% !important;
        }
        .ag-header-group-cell-label {
            justify-content: center !important;
            display: flex !important;
        }
        
        /* ELIMINATE WHITE SPACE - USE FULL HEIGHT */
        .ag-root-wrapper {
            height: auto !important;
            min-height: 400px !important;
        }
        .ag-body-viewport {
            height: auto !important;
        }
        div[data-testid="stAgGrid"] {
            height: auto !important;
        }
        .ag-body-container {
            height: auto !important;
        }
        
        /* FINAL NUCLEAR OPTION - TARGET COLUMNS BY EXACT ATTRIBUTE */
        [col-id="Nominal (in)"] .ag-header-cell-label,
        [col-id="Velocity (ft/s)"] .ag-header-cell-label {
            text-align: center !important;
            justify-content: center !important;
            display: flex !important;
            align-items: center !important;
            width: 100% !important;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )

    # Header with optional logo (prefers workspace logo file if present)
    col_title, col_logo = st.columns([3, 1])
    with col_title:
        st.title('Pipe Sizing — Explorer')
    with col_logo:
        workspace_logo = None
        app_dir = Path(__file__).parent
        # Look for JBDG logo first
        jbdg_logo = app_dir / 'JBDG Logo-2.jpg'
        if jbdg_logo.exists():
            workspace_logo = str(jbdg_logo)
        else:
            # Fallback to other logo files
            for ext in ('png', 'jpg', 'jpeg'):
                logo_path = app_dir / f'logo.{ext}'
                if logo_path.exists():
                    workspace_logo = str(logo_path)
                    break
        if workspace_logo:
            st.image(workspace_logo, width=200)

    # Load frankthearchitect font from the app directory
    embedded_font_css = None
    try:
        frank_path = Path(__file__).parent / 'Frank the Architect.TTF'
        if frank_path.exists():
            with open(frank_path, 'rb') as f:
                font_bytes = f.read()
            font_b64 = base64.b64encode(font_bytes).decode('utf-8')
            embedded_font_css = f"@font-face {{ font-family: 'FrankTheArchitect'; src: url('data:font/truetype;base64,{font_b64}') format('truetype'); }}"
    except Exception:
        pass

    # Use default logo color
    logo_color = '#0b82bf'

    # Inject FrankTheArchitect font CSS for all text
    font_css_block = embedded_font_css or "@font-face { font-family: 'FrankTheArchitect'; src: local('FrankTheArchitect'), local('Architect'); }"
    st.markdown(f"""
    <style>
    {font_css_block}
    html, body, [class*="css"], .stApp, .stMarkdown, h1, h2, h3, h4, h5, h6, p, div, span {{ font-family: FrankTheArchitect, 'Architect', monospace !important; }}
    .kpi-badge {{
        display:inline-block; padding:8px 14px; border-radius:8px; color: white; font-weight:700; font-size:20px; font-family: FrankTheArchitect, monospace;
    }}
    .logo-accent {{ background: linear-gradient(90deg, {logo_color}, #ffffff22); padding:6px; border-radius:8px }}
    /* ULTIMATE SOLUTION: Completely replace expandable sections with custom styling */
    .stExpander {{ 
        background: white !important; 
        border: 3px solid #0b82bf !important; 
        border-radius: 10px !important; 
        margin: 10px 0 !important;
        overflow: hidden !important;
        position: relative !important;
    }}
    .stExpander details {{ 
        background: white !important; 
        border: none !important;
        margin: 0 !important;
        padding: 0 !important;
    }}
    .stExpander details summary {{ 
        background: #f0f8ff !important; 
        padding: 15px !important; 
        font-weight: bold !important; 
        cursor: pointer !important;
        border: none !important;
        position: relative !important;
        z-index: 1000 !important;
    }}
    .stExpander details[open] summary {{ 
        background: #e6f3ff !important; 
        border-bottom: 2px solid #0b82bf !important;
    }}
    /* NUCLEAR APPROACH: Hide everything that could contain keyboard text */
    .stExpander *::before, .stExpander *::after {{ 
        display: none !important; 
        visibility: hidden !important; 
        content: "" !important; 
        font-size: 0 !important;
        opacity: 0 !important;
    }}
    .stExpander summary::marker {{ display: none !important; }}
    .stExpander summary::-webkit-details-marker {{ display: none !important; }}
    /* Hide any icons or symbols */
    .stExpander .material-icons, .stExpander .material-symbols-outlined {{ 
        display: none !important; 
        visibility: hidden !important;
        font-size: 0 !important;
    }}
    </style>
    """, unsafe_allow_html=True)

    

    # Load workbook from the app directory
    excel_path = Path(__file__).parent / 'pipe_sizing.xlsx'
    try:
        with open(excel_path, 'rb') as f:
            wb_bytes = f.read()
    except FileNotFoundError:
        st.error(f'`pipe_sizing.xlsx` not found at {excel_path}. Please ensure the file exists in the same directory as this app.')
        return

    # Load workbook (formulas and values)
    wb = load_workbook(filename=BytesIO(wb_bytes), data_only=False)
    wb_vals = load_workbook(filename=BytesIO(wb_bytes), data_only=True)

    # Use the first sheet automatically (no display needed)
    sheet = wb.sheetnames[0]
    ws = wb[sheet]
    ws_vals = wb_vals[sheet]


    def find_label_row(label_text_prefix):
        """Find a row index where column A starts with label_text_prefix (case-insensitive)."""
        for r in range(1, ws.max_row + 1):
            v = ws.cell(row=r, column=1).value
            if isinstance(v, str) and v.strip().lower().startswith(label_text_prefix.lower()):
                return r
        return None


    # Read inputs by label (robust to small layout shifts)
    flow_row = find_label_row('Flow Rate')
    line_type_row = find_label_row('Line Type')
    nu_row = find_label_row('Water')

    # fallback row numbers if detection fails (based on current workbook)
    if flow_row is None:
        flow_row = 5
    if line_type_row is None:
        line_type_row = 6
    if nu_row is None:
        nu_row = 8


    def get_cell_value(r, c):
        return ws_vals.cell(row=r, column=c).value

    flow_gpm = get_cell_value(flow_row, 2) or 100.0
    line_type = get_cell_value(line_type_row, 2) or 'Suction'

    # Find constants by scanning the sheet for known labels in column D/E
    constants = {}
    for r in range(1, ws.max_row + 1):
        label = ws.cell(row=r, column=4).value  # column D often contains constant labels
        val = ws_vals.cell(row=r, column=5).value  # column E often contains the numeric value
        if isinstance(label, str):
            constants[label.strip()] = val

    gal_to_ft3 = constants.get('gal_to_ft^3', 0.133681)
    sec_per_min = constants.get('sec_per_min', 60.0)
    pi = constants.get('π', 3.141592653589793)

    # kinematic viscosity is often in column B of its label row
    nu = get_cell_value(nu_row, 2) or 1.1e-05

    st.sidebar.subheader('Inputs')
    flow_gpm = st.sidebar.number_input('Flow Rate (gpm)', value=float(flow_gpm))

    # Restrict line type to only Suction or Discharge
    line_type = st.sidebar.selectbox('Line Type', options=['Suction', 'Discharge'], index=0 if (str(line_type).lower().startswith('suction')) else 1, help='Choose Suction or Discharge')
    st.sidebar.write('Water ν (ft²/s):', nu)

    # Threshold controls (using buttons instead of expanders)
    st.sidebar.markdown('&nbsp;', unsafe_allow_html=True)
    if st.sidebar.button('⚙️ Advanced Thresholds', key='thresholds_btn'):
        st.session_state.show_thresholds = not st.session_state.get('show_thresholds', False)
    
    if st.session_state.get('show_thresholds', False):
        if line_type == 'Suction':
            default_design = 4.5
            default_line = 6.0
        else:
            default_design = 6.0
            default_line = 8.0
        design_limit = st.sidebar.number_input('Design limit (ft/s)', value=float(default_design), help='Velocity considered fully acceptable')
        line_limit = st.sidebar.number_input('Line limit (ft/s)', value=float(default_line), help='Upper limit for this line type; velocities above this are unacceptable')
        st.sidebar.caption('Status rule: Acceptable if ≤ Design limit; Above design limit if ≤ Line limit; Unacceptable otherwise')
    else:
        # Use defaults when not shown
        if line_type == 'Suction':
            design_limit = 4.5
            line_limit = 6.0
        else:
            design_limit = 6.0
            line_limit = 8.0
    
    st.sidebar.container()
    st.sidebar.markdown('---')
    
    st.sidebar.markdown('---')  # Add separator


    # Debug toggle
    st.sidebar.container()
    st.sidebar.markdown('&nbsp;', unsafe_allow_html=True)  # Add space  
    debug = st.sidebar.checkbox('Show debug info', value=False)
    st.sidebar.container()

    # Locate the pipe size table by finding the header row that starts with 'Nominal Size'
    table_header_row = None
    for r in range(1, ws.max_row + 1):
        v = ws.cell(row=r, column=1).value
        if isinstance(v, str) and v.strip().lower().startswith('nominal size'):
            table_header_row = r
            break

    if table_header_row is None:
        st.error('Could not find the pipe size table header in the sheet. Ensure the header starts with "Nominal Size" in column A.')
        return

    # Read table rows until first blank nominal size
    rows = []
    r = table_header_row + 1
    while r <= ws.max_row:
        nominal = ws_vals.cell(row=r, column=1).value
        if nominal is None:
            break
        inner_d = ws_vals.cell(row=r, column=2).value
        rows.append({'nominal_in': nominal, 'inner_in': inner_d, 'row': r})
        r += 1

    if not rows:
        st.error('No pipe sizes found under the table header.')
        return

    # Compute derived values
    data = []
    for item in rows:
        D_in = float(item['inner_in'])
        nominal_size = float(item['nominal_in'])
        
        # FORCE SKIP 1 INCH PIPE - only process if >= 1.5 inches
        if nominal_size < 1.5:
            continue
            
        area_ft2 = (pi * (D_in / 12) ** 2) / 4
        velocity = (flow_gpm * gal_to_ft3 / sec_per_min) / area_ft2
        # status using thresholds
        status_suction = 'Acceptable' if velocity <= design_limit else ('Above design limit' if velocity <= line_limit else 'Unacceptable')
        status_return = 'Acceptable' if velocity <= design_limit else ('Above design limit' if velocity <= line_limit else 'Unacceptable')
        # Reynolds number: Re = V * D(ft) / nu
        Re = velocity * (D_in / 12) / nu
        data.append({'Nominal (in)': nominal_size,
                     'Inner D (in)': D_in,
                     'Area (ft^2)': area_ft2,
                     'Velocity (ft/s)': velocity,
                     'Suction Status': status_suction,
                     'Return Status': status_return,
                     'Reynolds': Re,
                     'row': item['row']})

    df = pd.DataFrame(data)

    # Show debug info if toggled
    if debug:
        st.sidebar.write('Detected rows', rows[:6])
        st.sidebar.write('Constants', constants)

    # Choose which status column to display based on line type
    status_col = 'Suction Status' if line_type == 'Suction' else 'Return Status'
    df['Status'] = df[status_col]

    # Determine recommended size using the chosen line_limit
    active_limit = float(line_limit)
    recommended_df = df[df['Velocity (ft/s)'] <= active_limit]
    recommended_size = None
    recommended_velocity = None
    if not recommended_df.empty:
        # Get the first (smallest) acceptable size
        first_acceptable = recommended_df.iloc[0]
        recommended_size = first_acceptable['Nominal (in)']
        recommended_velocity = first_acceptable['Velocity (ft/s)']

    st.subheader('Computed pipe table')

    # Use AgGrid for nicer interactive table with conditional text coloring
    # Create ABSOLUTE MINIMALIST table - just pipe size and velocity!
    display_df = df[['Nominal (in)', 'Velocity (ft/s)']].copy()
    # Round velocity to 2 decimal places for cleaner display
    display_df['Velocity (ft/s)'] = display_df['Velocity (ft/s)'].round(2)
    
    # RESTART WITH NEW COLUMN NAMES TO BREAK CACHING
    display_df = display_df.rename(columns={
        'Nominal (in)': 'Nominal Pipe Size (in)',
        'Velocity (ft/s)': 'Velocity of water (ft/s)'
    })
    
    # FILTER OUT 12 INCH PIPE - we don't need it!
    display_df = display_df[display_df['Nominal Pipe Size (in)'] != 12.0]
    
    # SCREW AGGRID - LET'S MAKE OUR OWN BEAUTIFUL TABLE!
    
    # Build the table using st.write instead of st.markdown
    html_table = """
    <div style="display: flex; justify-content: center; margin: 20px 0;">
        <table style="border-collapse: collapse; width: 80%; max-width: 600px; font-family: 'FrankTheArchitect', monospace; font-size: 18px; background-color: white; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
            <thead>
                <tr style="background-color: #0b82bf; color: white;">
                    <th style="padding: 15px 20px; text-align: center; font-weight: bold; border: none;">Nominal Pipe Size (in)</th>
                    <th style="padding: 15px 20px; text-align: center; font-weight: bold; border: none;">Velocity of water (ft/s)</th>
                </tr>
            </thead>
            <tbody>
    """
    
    # Add each row with color coding
    for _, row in display_df.iterrows():
        velocity = row['Velocity of water (ft/s)']
        
        # Color code the velocity
        if velocity > line_limit:
            color = '#d62728'  # Red
        elif velocity > design_limit:
            color = '#ff7f0e'  # Orange
        else:
            color = '#2ca02c'  # Green
            
        html_table += f'<tr style="border-bottom: 1px solid #eee;"><td style="padding: 12px 20px; text-align: center; font-weight: bold; border: none;">{row["Nominal Pipe Size (in)"]}</td><td style="padding: 12px 20px; text-align: center; font-weight: bold; color: {color}; border: none;">{velocity}</td></tr>'
    
    html_table += """
            </tbody>
        </table>
    </div>
    """
    
    # Try using st.write instead of st.markdown
    st.write(html_table, unsafe_allow_html=True)
    
    # ULTIMATE HEADER CENTERING WITH JAVASCRIPT
    st.markdown("""
    <script>
    function nuclearHeaderCentering() {
        console.log("Running nuclear header centering...");
        
        // Find all header cells
        var headers = document.querySelectorAll('.ag-header-cell');
        console.log("Found headers:", headers.length);
        
        headers.forEach(function(header, index) {
            console.log("Processing header", index);
            
            // Get all child elements
            var label = header.querySelector('.ag-header-cell-label');
            var text = header.querySelector('.ag-header-cell-text');
            
            if (label) {
                // NUCLEAR APPROACH - completely replace the content
                var originalText = label.textContent || label.innerText;
                console.log("Original text:", originalText);
                
                // Clear everything and rebuild centered
                label.innerHTML = '<div style="width: 100%; text-align: center; display: flex; justify-content: center; align-items: center; font-family: FrankTheArchitect, monospace; font-weight: bold; font-size: 18px;">' + originalText + '</div>';
                
                // Also force styles on the label itself
                label.style.width = '100%';
                label.style.display = 'flex';
                label.style.justifyContent = 'center';
                label.style.textAlign = 'center';
            }
            
            // Force header cell styles
            header.style.textAlign = 'center';
            header.style.justifyContent = 'center';
        });
    }
    
    // Run with multiple delays - AgGrid is sneaky!
    setTimeout(nuclearHeaderCentering, 100);
    setTimeout(nuclearHeaderCentering, 500);
    setTimeout(nuclearHeaderCentering, 1000);
    setTimeout(nuclearHeaderCentering, 2000);
    setTimeout(nuclearHeaderCentering, 3000);
    
    // Keep trying every 2 seconds
    setInterval(nuclearHeaderCentering, 2000);
    </script>
    """, unsafe_allow_html=True)

    # Show recommended size badge with color (green/yellow/red) and include 'in'
    def badge_for_velocity(vel):
        if vel <= design_limit:
            return ('#2ca02c', 'Acceptable')
        if vel <= line_limit:
            return ('#ff7f0e', 'Above design limit')
        return ('#d62728', 'Unacceptable')

    # Choose a representative velocity for the badge: the smallest velocity that meets the active_limit,
    # or the overall max if none meet the limit. This is clearer than the previous one-liner.
    try:
        vel_candidates = df.loc[df['Velocity (ft/s)'] <= active_limit, 'Velocity (ft/s)']
        vel_for_badge = float(vel_candidates.min()) if not vel_candidates.empty else float(df['Velocity (ft/s)'].max())
    except Exception:
        vel_for_badge = float(df['Velocity (ft/s)'].max()) if not df.empty else 0.0
    badge_color, badge_label = badge_for_velocity(vel_for_badge)
    with st.container():
        col_a, col_b = st.columns([1, 3])
        with col_a:
            st.markdown('**Recommended**')
            if recommended_size and recommended_velocity:
                st.markdown(f"<div class='kpi-badge' style='background:{badge_color}'> {recommended_size} in</div>", unsafe_allow_html=True)
                st.markdown(f"<small style='color: {badge_color}; font-weight: bold;'>Velocity: {recommended_velocity:.2f} ft/s</small>", unsafe_allow_html=True)
            else:
                st.markdown(f"<div class='kpi-badge' style='background:{badge_color}'> None</div>", unsafe_allow_html=True)
        with col_b:
            st.markdown(f"**Status:** {badge_label}  •  *Limit used:* {active_limit} ft/s")

    # Status explanation (using buttons instead of expanders)
    st.container()
    st.markdown('&nbsp;', unsafe_allow_html=True)
    if st.button('📋 Show Status Explanation', key='status_explanation'):
        st.info('''
        **Status Guide:**
        - **Acceptable** 🟢: Velocity ≤ Design limit (fully acceptable)
        - **Above design limit** 🟡: Design limit < Velocity ≤ Line limit (use with caution)
        - **Unacceptable** 🔴: Velocity > Line limit (do not use)
        ''')
    
    st.container()
    st.markdown('---')

    # Diagram / chart of velocities vs size (improved visuals)
    st.subheader('Velocity vs Pipe Size')
    # Build the chart robustly: convert and sort data, handle empty cases, and catch Altair errors
    if df.empty:
        st.info('No pipe sizes available to chart.')
    else:
        try:
            # Ensure numeric velocity and nominal ordering
            df['Velocity (ft/s)'] = pd.to_numeric(df['Velocity (ft/s)'], errors='coerce')
            # sanitize infinite values (avoid chained-assignment inplace warning)
            df['Velocity (ft/s)'] = df['Velocity (ft/s)'].replace([float('inf'), float('-inf')], pd.NA)

            # report NaNs and dtypes if debug
            if debug:
                st.sidebar.write('DataFrame dtypes:')
                st.sidebar.write(df.dtypes.astype(str).to_dict())
                st.sidebar.write('DataFrame head:')
                st.sidebar.write(df.head().to_dict(orient='records'))
                st.sidebar.write('Velocity NaN count:', int(df['Velocity (ft/s)'].isna().sum()))

            # keep nominal as string for category axis but sort by numeric value properly
            try:
                df['_nominal_sort'] = pd.to_numeric(df['Nominal (in)'], errors='coerce')
                # Sort dataframe by nominal size for proper chart ordering
                df = df.sort_values('_nominal_sort').reset_index(drop=True)
            except Exception:
                df['_nominal_sort'] = range(len(df))
            df['_nominal_label'] = df['Nominal (in)'].astype(str)

            # drop rows without numeric velocities before charting
            chart_df = df.dropna(subset=['Velocity (ft/s)']).copy()
            # FILTER OUT 12 INCH PIPE FROM CHART TOO!
            chart_df = chart_df[chart_df['Nominal (in)'] != 12.0]
            
            if chart_df.empty:
                st.info('No valid numeric velocities to chart after cleaning the data. See Chart debug below for computed values.')
                with st.expander('Chart debug — computed velocities', expanded=True):
                    # show computed velocities and source fields so user can see why chart is empty
                    try:
                        display_df = df[['Nominal (in)', 'Inner D (in)', 'Velocity (ft/s)']].copy()
                        display_df['Velocity (ft/s)'] = display_df['Velocity (ft/s)'].map(lambda v: f"{v:.6f}" if pd.notna(v) else 'NaN')
                        st.table(display_df)
                    except Exception:
                        st.write(df.head(20).to_dict(orient='records'))
                if debug:
                    st.sidebar.write('Cleaned df (first 20 rows):')
                    st.sidebar.write(df.head(20).to_dict(orient='records'))
            else:
                # Create color-coded bar chart based on status
                try:
                    # Sort chart data by nominal size
                    chart_df = chart_df.sort_values('_nominal_sort').reset_index(drop=True)
                    
                    # Add colors based on velocity status
                    chart_df['Color'] = chart_df['Velocity (ft/s)'].apply(
                        lambda v: '#2ca02c' if v <= design_limit else ('#ff7f0e' if v <= line_limit else '#d62728')
                    )
                    
                    # Create chart data with colors
                    chart_data = pd.DataFrame({
                        'Pipe Size': chart_df['_nominal_label'],
                        'Velocity': chart_df['Velocity (ft/s)'],
                        'Color': chart_df['Color'],
                        'Sort Order': chart_df['_nominal_sort']
                    })
                    
                    # Use Altair for color-coded bars with proper sorting
                    chart = alt.Chart(chart_data).mark_bar().encode(
                        x=alt.X('Pipe Size:N', title='Nominal Size (in)', sort=alt.EncodingSortField(field='Sort Order', op='mean')),
                        y=alt.Y('Velocity:Q', title='Velocity (ft/s)'),
                        color=alt.Color('Color:N', scale=None)
                    ).properties(height=360)
                    
                    st.altair_chart(chart, use_container_width=True)
                    
                    # Add limit line info below chart
                    st.caption(f'🟢 Green: ≤ {design_limit} ft/s (Acceptable)  |  🟡 Yellow: ≤ {line_limit} ft/s (Above design)  |  🔴 Red: > {line_limit} ft/s (Unacceptable)')
                    altair_ok = True
                except Exception:
                    # Fallback to simple bar chart
                    chart_data = chart_df.sort_values('_nominal_sort').set_index('_nominal_label')['Velocity (ft/s)']
                    st.bar_chart(chart_data)
                    st.caption(f'Horizontal reference: {active_limit} ft/s limit')
                    altair_ok = True                # Chart rendered successfully - no additional stats needed
        except Exception:
            st.error('Could not render chart. Enable debug to see details.')
            if debug:
                st.sidebar.error('Chart exception:')
                st.sidebar.text(traceback.format_exc())

    # Export button only shown when we have data
    # removed CSV download as requested

    st.caption('Notes: thresholds and constants were read from the workbook where possible. Adjust inputs in the sidebar to recalculate.')


if __name__ == '__main__':
    main()

